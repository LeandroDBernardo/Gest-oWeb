﻿using GestaoEsportsWeb.Data;
using GestaoEsportsWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GestaoEsportsWeb.Controllers
{
    public class EquipaController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EquipaController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Equipa
        public async Task<IActionResult> Index()
        {
            var equipas = await _context.Equipas
                .Include(e => e.Jogadores)
                .ToListAsync();

            return View(equipas);
        }

        // GET: Equipa/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var equipa = await _context.Equipas
                .Include(e => e.Jogadores)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (equipa == null)
                return NotFound();

            return View(equipa);
        }

        // GET: Equipa/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Equipa/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Equipa equipa)
        {
            if (ModelState.IsValid)
            {
                _context.Add(equipa);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(equipa);
        }

        // GET: Equipa/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var equipa = await _context.Equipas.FindAsync(id);

            if (equipa == null)
                return NotFound();

            return View(equipa);
        }

        // POST: Equipa/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Equipa equipa)
        {
            if (id != equipa.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(equipa);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(equipa);
        }

        // GET: Equipa/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var equipa = await _context.Equipas
                .Include(e => e.Jogadores)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (equipa == null)
                return NotFound();

            return View(equipa);
        }

        // POST: Equipa/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var equipa = await _context.Equipas.FindAsync(id);

            if (equipa != null)
            {
                _context.Equipas.Remove(equipa);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}