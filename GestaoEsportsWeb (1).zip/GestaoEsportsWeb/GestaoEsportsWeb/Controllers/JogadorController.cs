﻿using GestaoEsportsWeb.Data;
using GestaoEsportsWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GestaoEsportsWeb.Controllers
{
    public class JogadorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public JogadorController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Lista + pesquisa
        public async Task<IActionResult> Index(string pesquisa)
        {
            var jogadores = _context.Jogadores
                .Include(j => j.Equipa)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(pesquisa))
            {
                jogadores = jogadores.Where(j =>
                    j.Nickname.Contains(pesquisa));
            }

            ViewBag.Pesquisa = pesquisa;

            return View(await jogadores.ToListAsync());
        }

        // Detalhes
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var jogador = await _context.Jogadores
                .Include(j => j.Equipa)
                .FirstOrDefaultAsync(j => j.Id == id);

            if (jogador == null)
                return NotFound();

            return View(jogador);
        }

        // Criar
        public IActionResult Create()
        {
            ViewBag.Equipas = new SelectList(
                _context.Equipas,
                "Id",
                "Nome");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Jogador jogador)
        {
            if (ModelState.IsValid)
            {
                _context.Jogadores.Add(jogador);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            ViewBag.Equipas = new SelectList(
                _context.Equipas,
                "Id",
                "Nome",
                jogador.EquipaId);

            return View(jogador);
        }

        // Editar
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var jogador = await _context.Jogadores.FindAsync(id);

            if (jogador == null)
                return NotFound();

            ViewBag.Equipas = new SelectList(
                _context.Equipas,
                "Id",
                "Nome",
                jogador.EquipaId);

            return View(jogador);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            Jogador jogador)
        {
            if (id != jogador.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(jogador);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            ViewBag.Equipas = new SelectList(
                _context.Equipas,
                "Id",
                "Nome",
                jogador.EquipaId);

            return View(jogador);
        }

        // Eliminar
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var jogador = await _context.Jogadores
                .Include(j => j.Equipa)
                .FirstOrDefaultAsync(j => j.Id == id);

            if (jogador == null)
                return NotFound();

            return View(jogador);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var jogador = await _context.Jogadores.FindAsync(id);

            if (jogador != null)
            {
                _context.Jogadores.Remove(jogador);

                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}