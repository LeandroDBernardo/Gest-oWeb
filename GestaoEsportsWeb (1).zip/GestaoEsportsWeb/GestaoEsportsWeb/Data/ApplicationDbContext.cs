﻿using GestaoEsportsWeb.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace GestaoEsportsWeb.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Equipa> Equipas { get; set; }

        public DbSet<Jogador> Jogadores { get; set; }
    }
}