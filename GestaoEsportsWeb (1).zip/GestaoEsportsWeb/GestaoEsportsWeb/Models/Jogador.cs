﻿using System.ComponentModel.DataAnnotations;

namespace GestaoEsportsWeb.Models
{
    public class Jogador
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(50)]
        public string Nickname { get; set; }

        [Range(15, 45)]
        public int Idade { get; set; }

        [Range(0, 100)]
        public double Pontuacao { get; set; }

        public int? EquipaId { get; set; }

        public Equipa? Equipa { get; set; }
    }
}
