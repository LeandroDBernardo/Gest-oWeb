﻿using System.ComponentModel.DataAnnotations;

namespace GestaoEsportsWeb.Models
{
    public class Equipa
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(100)]
        public string Pais { get; set; }
    }
}
